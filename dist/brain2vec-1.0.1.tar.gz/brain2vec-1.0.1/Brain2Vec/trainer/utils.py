# Copyright 2026 CBICA
#
# Author: Spiros Maggioros
#
# References:
#   facebookresearch: https://github.com/facebookresearch/mae/blob/main/
#
# Licenced under CBICA's non-Commercial Software Agreement:
# https://www.med.upenn.edu/cbica/software-agreement-non-commercial.html


import builtins
import datetime
import os
from pathlib import Path
from typing import Any

import torch
import torch.distributed as dist


class NativeScalerWithGradNormCount:
    state_dict_key = "amp_scaler"

    def __init__(self) -> None:
        self._scaler = torch.cuda.amp.GradScaler()

    def __call__(
        self,
        loss: torch.Tensor,
        optimizer: torch.nn.Module,
        clip_grad: Any = None,
        parameters: Any = None,
        create_graph: bool = False,
        update_grad: bool = True,
    ) -> Any:
        self._scaler.scale(loss).backward(create_graph=create_graph)
        if update_grad:
            if clip_grad is not None:
                assert parameters is not None
                self._scaler.unscale_(
                    optimizer
                )  # unscale the gradients of optimizer's assigned params in-place
                norm = torch.nn.utils.clip_grad_norm_(parameters, clip_grad)
            else:
                self._scaler.unscale_(optimizer)
                norm = get_grad_norm_(parameters)
            self._scaler.step(optimizer)
            self._scaler.update()
        else:
            norm = None
        return norm

    def state_dict(self) -> Any:
        return self._scaler.state_dict()

    def load_state_dict(self, state_dict: Any) -> Any:
        self._scaler.load_state_dict(state_dict)


def get_grad_norm_(parameters: Any, norm_type: float = 2.0) -> torch.Tensor:
    if isinstance(parameters, torch.Tensor):
        parameters = [parameters]
    parameters = [p for p in parameters if p.grad is not None]
    norm_type = float(norm_type)
    if len(parameters) == 0:
        return torch.tensor(0.0)
    device = parameters[0].grad.device
    if torch.isinf(torch.tensor(norm_type)):
        total_norm = max(p.grad.detach().abs().max().to(device) for p in parameters)
    else:
        total_norm = torch.norm(
            torch.stack(
                [torch.norm(p.grad.detach(), norm_type).to(device) for p in parameters]
            ),
            norm_type,
        )
    return total_norm


def init_distributed_mode(args: Any) -> None:
    if "SLURM_PROCID" in os.environ:
        args.rank = int(os.environ["SLURM_PROCID"])
        args.world_size = int(os.environ["SLURM_NTASKS"])
        args.gpu = args.rank % torch.cuda.device_count()

        node_list = os.environ.get("SLURM_JOB_NODELIST")
        if node_list:
            import subprocess

            master_node = (
                subprocess.check_output(
                    f"scontrol show hostnames {node_list} | head -n 1", shell=True
                )
                .decode()
                .strip()
            )
            os.environ["MASTER_ADDR"] = master_node
        else:
            os.environ["MASTER_ADDR"] = "localhost"

        os.environ["MASTER_PORT"] = os.environ.get("MASTER_PORT", "12355")

        args.distributed = True
    else:
        print("Not using distributed mode")
        setup_distributed(is_master=True)
        args.distributed = False
        return

    torch.cuda.set_device(args.gpu)
    args.dist_backend = "nccl"
    print(
        "| distributed init (rank {}): {}, gpu {}".format(
            args.rank, args.dist_url, args.gpu
        ),
        flush=True,
    )

    torch.distributed.init_process_group(
        backend=args.dist_backend,
        init_method=args.dist_url,
        world_size=args.world_size,
        rank=args.rank,
    )
    torch.distributed.barrier()
    setup_distributed(args.rank == 0)


def setup_distributed(is_master: bool) -> None:
    builtin_print = builtins.print

    def print(*args, **kwargs):  # type: ignore
        force = kwargs.pop("force", False)
        force = force or (get_world_size() > 8)
        if is_main_process() or force:
            now = datetime.datetime.now().time()
            builtin_print("[{}] ".format(now), end="")
            builtin_print(*args, **kwargs)

    builtins.print = print


def get_world_size() -> int:
    if not dist.is_available() or not dist.is_initialized():
        return 1

    return int(dist.get_world_size())


def get_rank() -> int:
    if not dist.is_available() or not dist.is_initialized():
        return 0

    return int(dist.get_rank())


def is_main_process() -> bool:
    return get_rank() == 0


class EarlyStopper:
    """
    Performs early stopping as PyTorch doesn't have an implemented one
    """

    def __init__(
        self, patience: int = 1, min_delta: float = 0.0, increase: bool = False
    ) -> None:
        self.patience = patience
        self.min_delta = min_delta
        self.counter = 0
        self.increase = increase
        self.best_value = float("-inf") if increase else float("inf")

    def early_stop(self, validation_val: float) -> bool:
        if not self.increase:
            if validation_val <= self.best_value:
                self.best_value = validation_val
                self.counter = 0
            else:
                self.counter += 1
        else:
            if validation_val >= self.best_value:
                self.best_value = validation_val
                self.counter = 0
            else:
                self.counter += 1

        return self.counter > self.patience


def save_on_master(*args: Any, **kwargs: Any) -> None:
    if is_main_process():
        torch.save(*args, **kwargs)


def all_reduce_mean(x: Any) -> Any:
    world_size = get_world_size()
    if world_size > 1:
        x_reduce = torch.tensor(x).cuda()
        dist.all_reduce(x_reduce)
        x_reduce /= world_size
        return x_reduce.item()
    else:
        return x


def save_model(
    model_without_ddp: torch.nn.Module, target_dir: str, model_name: str
) -> None:
    target_dir_path = Path(target_dir)
    target_dir_path.mkdir(parents=True, exist_ok=True)

    assert model_name.endswith(".pth") or model_name.endswith(
        ".pt"
    ), "model_name should end with '.pt' or '.pth'"
    model_save_path = target_dir_path / model_name

    print(f"[INFO] Saving model to: {model_save_path}")
    save_on_master(obj=model_without_ddp.state_dict(), f=model_save_path)


def load_weights(model: torch.nn.Module, model_weights: str, device: str) -> None:
    state_dict = torch.load(model_weights, map_location=torch.device(device))
    missing_keys, unexpected_keys = model.load_state_dict(state_dict, strict=False)

    total_model_keys = len(model.state_dict().keys())
    loaded_keys = total_model_keys - len(missing_keys)

    print(
        f"Successfully loaded: {loaded_keys} | Total missing keys: {missing_keys} | Total unexpected keys: {unexpected_keys}"
    )
